-- Milewyse: Konto selbst löschen (DSGVO Art. 17).
-- Läuft mit erhöhten Rechten, löscht aber ausschließlich den gerade angemeldeten Nutzer.
create or replace function public.delete_own_account()
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if auth.uid() is null then
    raise exception 'not authenticated';
  end if;
  delete from auth.users where id = auth.uid();
end;
$$;

revoke all on function public.delete_own_account() from public, anon;
grant execute on function public.delete_own_account() to authenticated;
